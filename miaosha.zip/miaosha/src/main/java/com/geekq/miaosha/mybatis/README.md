### 前言  mybatis的一些使用
     SqlSession 的作用<br>
     1.像sql中传入语句<br>
     2.执行SQL语句<br>
     3.获取执行SQL语句的结果<br>
     4.事物的控制<br>
     
### 如何获得sqlsession?
 1. 配置文件获取数据库链接相关信息<br>
 2.通过配置文件来构建sqlsessionfactory<br>
 3.通过sqlsessionfactory打开数据库会话<br>



